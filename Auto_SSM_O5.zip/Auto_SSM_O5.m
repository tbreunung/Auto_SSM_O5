function [W,l,lambda,beta_1,beta_2]=Auto_SSM_O5(M,C,K,RHS,exps)
order=5;

dim=min(size(M));
A=[zeros(dim) eye(dim); -inv(M)*K -inv(M)*C];
[v,l]=polyeig(K,C,M)
V_small=v(:,1:2:2*dim)+v(:,2:2:2*dim);
fkt=diag(V_small.'*V_small);
for ii=1:dim
    V_small(:,ii)=V_small(:,ii)/sqrt(abs(fkt(ii)));
end


V=[V_small V_small;V_small*diag(l(1:2:2*dim)) V_small*conj(diag(l(1:2:2*dim)))];

diag(inv(V)*A*V)

consts_for_G=diag_NL_sys(V,RHS,exps,dim);

[W,l,lambda,beta_1,beta_2]=construct_SSM_TIV(consts_for_G,exps,dim,order);


end

function consts_for_G=diag_NL_sys(V,RHS,exps,dim)


tic
disp('start diagonalization')
for ii=1:length(exps(:,1))
    
    new_exps=[];
    consts=[];
    for jj=1:length(exps(1,:))
        
        if exps(ii,jj)~=0
            
            add_exps=multi_index(exps(ii,jj),2*dim,'same');
            add_consts=[];
            for  kk=1:length(add_exps(:,1))
                add_consts(kk,:)=[factorial(exps(ii,jj))/prod(factorial(add_exps(kk,:)))*prod(V(jj,:).^(add_exps(kk,:)))];
            end
            if isempty(new_exps)~=1
                
                 newexps_old=new_exps;
                 consts_old=consts;
                 consts=[];
                 tmp_exps=[];
                 tmp_consts=[];
                 for zeiger_old=1:length(consts_old)
                     
                     for zeiger_new=1:length(add_consts)
                         tmp_exps(end+1,:)=newexps_old(zeiger_old,:)+add_exps(zeiger_new,:);
                         tmp_consts(end+1)=add_consts(zeiger_new)*consts_old(zeiger_old);
                         
                     end
                 end
             new_exps=multi_index(sum(tmp_exps(1,:)),2*dim,'same');    
                 for zeiger_exps=1:length(new_exps(:,1))
                     idx=find(ismember(tmp_exps,new_exps(zeiger_exps,:),'rows'));
                     
                     consts(end+1)=sum(tmp_consts(idx));
                 end
            else
                consts=add_consts;
                new_exps=add_exps;
            
            end
        
            
                        
        end
       
        
    end

    const_for_y{ii}=consts;
    exp_for_y{ii}=new_exps;
%     for zeiger_exps=1:length(exps(:,1))
%         idx=find(ismember(new_exps,exps(zeiger_exps,:),'rows'));
%         consts_for_real(1,zeiger_exps)=sum(consts(idx))+consts_for_real(1,zeiger_exps);
%     end
    
    
    
    
end

toc
disp('half-time diagonalization')

Kstar=inv(V)*RHS;
consts_for_G=zeros(2*dim,length(exps(:,1)));
for zeiger_zeile=1:length(Kstar(:,1))
    
    for zeiger_spalte=1:length(Kstar(1,:))
       if Kstar(zeiger_zeile,zeiger_spalte)~=0
        const_tmp=[const_for_y{zeiger_spalte}].*Kstar(zeiger_zeile,zeiger_spalte);
        for zeiger_exps=1:length(exps(:,1))
            
            idx=find(ismember([exp_for_y{zeiger_spalte}],exps(zeiger_exps,:),'rows'));
            if isempty(const_tmp(idx))~=1
               consts_for_G(zeiger_zeile,zeiger_exps)=const_tmp(idx)+consts_for_G(zeiger_zeile,zeiger_exps);
            end
        end
       end
    end
end
toc
disp('diagonalization complete')

end

function [w,l,lambda,beta,gamma]=construct_SSM_TIV(consts_for_G,exps,dim,order)
idx=find(sum(exps,2)==1);
lams=diag([consts_for_G(:,idx)])
 str=input('Please specify l=???? \n','s');
 
lambda=lams;
l=str2num(str);
if l>dim || l<=0 || floor(l)~=l
    error('Please specify vaild l and restart.')
end
toc
disp('constructing SSM')
w=zeros(order+1,order+1,2*dim);
rsum=zeros(order+1,order+1,2*dim);
beta=0;
gamma=0;
w(2,1,l)=1;
w(1,2,l+dim)=1;
sum_beta=0;
sum_beta2=0;
if order>1
w(3,1,:)=G_at(consts_for_G,exps,2,l)./(2*lambda(l)*ones(2*dim,1)-lambda);%(2*Mus(l)*ones(dim,1)-Mus); %
w(2,2,:)=G_at(consts_for_G,exps,[1 1],[l l+dim])./((lambda(l)+lambda(l+dim))*ones(2*dim,1)-lambda);%((Mus(l)+Mus(l+dim))*ones(dim,1)-Mus);%
w(1,3,:)=G_at(consts_for_G,exps,2,l+dim)./(2*lambda(l+dim)*ones(2*dim,1)-lambda);%(2*Mus(l+dim)*ones(dim,1)-Mus);%
end


if order>2
for q=1:2*dim
    
    rsum(4,1,:)=squeeze(rsum(4,1,:))+(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]).*w(3,1,q);
    rsum(1,4,:)=squeeze(rsum(1,4,:))+(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(1,3,q);
    rsum(3,2,:)=squeeze(rsum(3,2,:))+(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]).*w(2,2,q)+(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(3,1,q);
    rsum(2,3,:)=squeeze(rsum(2,3,:))+(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]).*w(1,3,q)+(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(2,2,q);
    
    
    
    tmp1=(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]);
    tmp2=(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]);
    sum_beta=sum_beta+tmp1(l)*w(2,2,q)+tmp2(l)*w(3,1,q);
    
    tmp3=(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]);
    tmp4=(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]);
    sum_beta2=sum_beta2+tmp3(l+dim)*w(2,2,q)+tmp4(l+dim)*w(1,3,q);
end


w(4,1,:)=(squeeze(rsum(4,1,:))+G_at(consts_for_G,exps,3,l))./(3*lambda(l)*ones(2*dim,1)-lambda);%(3*Mus(l)*ones(dim,1)-Mus);%
w(1,4,:)=(squeeze(rsum(1,4,:))+G_at(consts_for_G,exps,3,l+dim))./(3*lambda(l+dim)*ones(2*dim,1)-lambda);%(3*Mus(l+dim)*ones(2*dim,1)-Mus);%
w(3,2,:)=(squeeze(rsum(3,2,:))+G_at(consts_for_G,exps,[2 1],[l l+dim]))./((2*lambda(l)+lambda(l+dim))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
w(2,3,:)=(squeeze(rsum(2,3,:))+G_at(consts_for_G,exps,[1 2],[l l+dim]))./((2*lambda(l+dim)+lambda(l))*ones(2*dim,1)-lambda);%(2*Mus(l+dim)*Mus(l)*ones(2*dim,1)-Mus);%

w(3,2,l)=0;
w(2,3,l+dim)=0;
tmp=G_at(consts_for_G,exps,[2 1],[l l+dim]);
beta=sum_beta+tmp(l);

end

if order>3
    for q=1:2*dim
        
        
        
        tmpsum=zeros(order+1,order+1,2*dim);
        for p=q:2*dim
            tmpsum(5,1,:)=squeeze(tmpsum(5,1,:))+G_at(consts_for_G,exps,[1 1],[p q]).*w(3,1,q)*w(3,1,p);
            tmpsum(4,2,:)=squeeze(tmpsum(4,2,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(2,2,q)*w(3,1,p)+w(2,2,p)*w(3,1,q));
            tmpsum(3,3,:)=squeeze(tmpsum(3,3,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(3,1,q)*w(1,3,p)+w(1,3,q)*w(3,1,p)+w(2,2,q)*w(2,2,p));
            tmpsum(2,4,:)=squeeze(tmpsum(2,4,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(2,2,q)*w(1,3,p)+w(2,2,p)*w(1,3,q));
            tmpsum(1,5,:)=squeeze(tmpsum(1,5,:))+G_at(consts_for_G,exps,[1 1],[p q]).*w(1,3,q)*w(1,3,p);
        end
        rsum(5,1,:)=squeeze(rsum(5,1,:)+tmpsum(5,1,:))+(1+2*kDelta(l,q))*G_at(consts_for_G,exps,[2 1],[l q]).*w(3,1,q)+(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]).*w(4,1,q);
        rsum(4,2,:)=squeeze(rsum(4,2,:)+tmpsum(4,2,:))+(1+2*kDelta(l,q))*G_at(consts_for_G,exps,[2 1],[l q]).*w(2,2,q)+(1+kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(3,1,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(3,2,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(4,1,q);
        rsum(3,3,:)=squeeze(rsum(3,3,:)+tmpsum(3,3,:))+(1+2*kDelta(l,q))*G_at(consts_for_G,exps,[2 1],[l q]).*w(1,3,q)+(1+2*kDelta(l+dim,q))*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(3,1,q)+(1+kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(2,2,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(2,3,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(3,2,q);
        rsum(2,4,:)=squeeze(rsum(2,4,:)+tmpsum(2,4,:))+(1+2*kDelta(l+dim,q))*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(2,2,q)+(1+kDelta(l+dim,q)+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(3,1,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(2,3,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(1,4,q);
        rsum(1,5,:)=squeeze(rsum(1,5,:)+tmpsum(1,5,:))+(1+2*kDelta(l+dim,q))*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(1,3,q)+(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(1,4,q);
        
    end
    
    
    w(5,1,:)=(squeeze(rsum(5,1,:))+G_at(consts_for_G,exps,4,l))./(4*lambda(l)*ones(2*dim,1)-lambda);%(3*Mus(l)*ones(2*dim,1)-Mus);%
    w(4,2,:)=(squeeze(rsum(4,2,:))+G_at(consts_for_G,exps,[3 1],[l l+dim])-2*beta.*squeeze(w(3,1,:)))./((3*lambda(l)+lambda(l+dim))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
    w(3,3,:)=(squeeze(rsum(3,3,:))+G_at(consts_for_G,exps,[2 2],[l l+dim])-(beta+conj(beta)).*squeeze(w(2,2,:)))./((2*lambda(l)+2*lambda(l+dim))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
    w(2,4,:)=(squeeze(rsum(2,4,:))+G_at(consts_for_G,exps,[1 3],[l l+dim])-2*conj(beta).*squeeze(w(1,3,:)))./((3*lambda(l+dim)+lambda(l))*ones(2*dim,1)-lambda);%(2*Mus(l+dim)*Mus(l)*ones(2*dim,1)-Mus);%
    w(1,5,:)=(squeeze(rsum(1,5,:))+G_at(consts_for_G,exps,4,l+dim))./(4*lambda(l+dim)*ones(2*dim,1)-lambda);%(3*Mus(l+dim)*ones(2*dim,1)-Mus);%
    
end



if order>4
    for q=1:2*dim
        tmpsum=zeros(order+1,order+1,2*dim);
        
        for p=q:2*dim
            tmpsum(6,1,:)=squeeze(tmpsum(6,1,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(3,1,q)*w(4,1,p)+w(4,1,q)*w(3,1,p))+(1+kDelta(l,p)+kDelta(l,q))*G_at(consts_for_G,exps,[1 1 1],[l p q]).*w(3,1,q)*w(3,1,p);
            tmpsum(5,2,:)=squeeze(tmpsum(5,2,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(2,2,q)*w(4,1,p)+w(4,1,q)*w(2,2,p)+w(3,2,q)*w(3,1,p)+w(3,1,q)*w(3,2,p))+(1+kDelta(l,p)+kDelta(l,q))*G_at(consts_for_G,exps,[1 1 1],[l p q]).*(w(2,2,q)*w(3,1,p)+w(3,1,q)*w(2,2,p))+(1+kDelta(l+dim,p)+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1 1],[l+dim p q]).*(w(3,1,q)*w(3,1,p));
            tmpsum(4,3,:)=squeeze(tmpsum(4,3,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(1,3,q)*w(4,1,p)+w(4,1,q)*w(1,3,p)+w(3,2,q)*w(2,2,p)+w(2,2,q)*w(3,2,p)+w(3,1,q)*w(2,3,p)+w(2,3,q)*w(3,1,p))+(1+kDelta(l,p)+kDelta(l,q))*G_at(consts_for_G,exps,[1 1 1],[l p q]).*(w(2,2,q)*w(2,2,p)+w(1,3,q)*w(3,1,p)+w(3,1,q)*w(1,3,p))+(1+kDelta(l+dim,p)+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1 1],[l+dim p q]).*(w(2,2,q)*w(3,1,p)+w(2,2,p)*w(3,1,q));
            
            tmpsum(3,4,:)=squeeze(tmpsum(3,4,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(3,1,q)*w(1,4,p)+w(1,4,q)*w(3,1,p)+w(2,3,q)*w(2,2,p)+w(2,2,q)*w(2,3,p)+w(1,3,q)*w(3,2,p)+w(3,2,q)*w(1,3,p))+(1+kDelta(l+dim,p)+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1 1],[l+dim p q]).*(w(2,2,q)*w(2,2,p)+w(3,1,q)*w(1,3,p)+w(1,3,q)*w(3,1,p))+(1+kDelta(l,p)+kDelta(l,q))*G_at(consts_for_G,exps,[1 1 1],[l p q]).*(w(2,2,q)*w(1,3,p)+w(2,2,p)*w(1,3,q));
            tmpsum(2,5,:)=squeeze(tmpsum(2,5,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(2,2,q)*w(1,4,p)+w(1,4,q)*w(2,2,p)+w(2,3,q)*w(1,3,p)+w(1,3,q)*w(2,3,p))+(1+kDelta(l+dim,p)+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1 1],[l+dim p q]).*(w(2,2,q)*w(1,3,p)+w(1,3,q)*w(2,2,p))+(1+kDelta(l,p)+kDelta(l,q))*G_at(consts_for_G,exps,[1 1 1],[l p q]).*(w(1,3,q)*w(1,3,p));
            tmpsum(1,6,:)=squeeze(tmpsum(1,6,:))+G_at(consts_for_G,exps,[1 1],[p q]).*(w(1,3,q)*w(1,4,p)+w(1,4,q)*w(1,3,p))+(1+kDelta(l+dim,p)+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1 1],[l+dim p q]).*w(1,3,q)*w(1,3,p);
        end
        
        rsum(6,1,:)=squeeze(rsum(6,1,:)+tmpsum(6,1,:))+(1+3*kDelta(l,q))*G_at(consts_for_G,exps,[3 1],[l q]).*w(3,1,q)+(1+2*kDelta(l,q))*G_at(consts_for_G,exps,[2 1],[l q]).*w(4,1,q)+(1+kDelta(l,q))*G_at(consts_for_G,exps,[1 1],[l q]).*w(5,1,q);
        rsum(5,2,:)=squeeze(rsum(5,2,:)+tmpsum(5,2,:))+(1+3*kDelta(l,q))*G_at(consts_for_G,exps,[3 1],[l q]).*w(2,2,q)+(1+2*kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[2 1 1],[l l+dim q]).*w(3,1,q)+(1+kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(4,1,q)+(1+2*kDelta(l,q)).*G_at(consts_for_G,exps,[2 1],[l q]).*w(3,2,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(4,2,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(5,1,q);
        rsum(4,3,:)=squeeze(rsum(4,3,:)+tmpsum(4,3,:))+(1+3*kDelta(l,q))*G_at(consts_for_G,exps,[3 1],[l q]).*w(1,3,q)+(1+2*kDelta(l,q))*G_at(consts_for_G,exps,[2 1],[l q]).*w(2,3,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(3,3,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(4,2,q)+(1+2*kDelta(l+dim,q)).*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(4,1,q)+(1+2*kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[2 1 1],[l l+dim q]).*w(2,2,q)+(1+kDelta(l,q)+2*kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 2 1],[l l+dim q]).*w(3,1,q)+(1+kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(3,2,q);
        
        rsum(3,4,:)=squeeze(rsum(3,4,:)+tmpsum(3,4,:))+(1+3*kDelta(l+dim,q))*G_at(consts_for_G,exps,[3 1],[l+dim q]).*w(3,1,q)+(1+2*kDelta(l+dim,q))*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(3,2,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(3,3,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(2,4,q)+(1+2*kDelta(l,q)).*G_at(consts_for_G,exps,[2 1],[l q]).*w(1,4,q)+(1+2*kDelta(l+dim,q)+kDelta(l,q)).*G_at(consts_for_G,exps,[1 2 1],[l l+dim q]).*w(2,2,q)+(1+kDelta(l+dim,q)+2*kDelta(l,q)).*G_at(consts_for_G,exps,[2 1 1],[l l+dim q]).*w(1,3,q)+(1+kDelta(l+dim,q)+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(2,3,q);
        rsum(2,5,:)=squeeze(rsum(2,5,:)+tmpsum(2,5,:))+(1+3*kDelta(l+dim,q))*G_at(consts_for_G,exps,[3 1],[l+dim q]).*w(2,2,q)+(1+2*kDelta(l+dim,q)+kDelta(l,q)).*G_at(consts_for_G,exps,[1 2 1],[l l+dim q]).*w(1,3,q)+(1+kDelta(l,q)+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1 1],[l l+dim q]).*w(1,4,q)+(1+2*kDelta(l+dim,q)).*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(2,3,q)+(1+kDelta(l+dim,q)).*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(2,4,q)+(1+kDelta(l,q)).*G_at(consts_for_G,exps,[1 1],[l q]).*w(1,5,q);
        rsum(1,6,:)=squeeze(rsum(1,6,:)+tmpsum(1,6,:))+(1+3*kDelta(l+dim,q))*G_at(consts_for_G,exps,[3 1],[l+dim q]).*w(1,3,q)+(1+2*kDelta(l+dim,q))*G_at(consts_for_G,exps,[2 1],[l+dim q]).*w(1,4,q)+(1+kDelta(l+dim,q))*G_at(consts_for_G,exps,[1 1],[l+dim q]).*w(1,5,q);
        
        
        
    end
    
    
    w(6,1,:)=(squeeze(rsum(6,1,:))+G_at(consts_for_G,exps,5,l))./(5*lambda(l)*ones(2*dim,1)-lambda);%(3*Mus(l)*ones(2*dim,1)-Mus);%
    w(5,2,:)=(squeeze(rsum(5,2,:))+G_at(consts_for_G,exps,[4 1],[l l+dim])-3*beta*squeeze(w(4,1,:)))./((4*lambda(l)+lambda(l+dim))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
    w(4,3,:)=(squeeze(rsum(4,3,:))+G_at(consts_for_G,exps,[3 2],[l l+dim])-(conj(beta)+2*beta).*squeeze(w(3,2,:)))./((3*lambda(l)+2*lambda(l+dim))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
    
    w(3,4,:)=(squeeze(rsum(3,4,:))+G_at(consts_for_G,exps,[2 3],[l l+dim])-(beta+2*conj(beta)).*squeeze(w(2,3,:)))./((2*lambda(l)+3*lambda(l+dim))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
    w(2,5,:)=(squeeze(rsum(2,5,:))+G_at(consts_for_G,exps,[1 4],[l l+dim])-3*conj(beta).*squeeze(w(1,4,:)))./((4*lambda(l+dim)+lambda(l))*ones(2*dim,1)-lambda);%(2*Mus(l)*Mus(l+dim)*ones(2*dim,1)-Mus); %
    w(1,6,:)=(squeeze(rsum(1,6,:))+G_at(consts_for_G,exps,5,l+dim))./(5*lambda(l+dim)*ones(2*dim,1)-lambda);%(3*Mus(l)*ones(2*dim,1)-Mus);%
    
    gamma=w(4,3,l)*(3*lambda(l)+2*lambda(l+dim)-lambda(l));
    w(4,3,l)=0;
    w(3,4,l+dim)=0;
    
end
toc
disp('SSM constructed')
end



function G_at=G_at(const_for_G,exps,val,pos)


cmp_exp=zeros(1,length(exps(1,:)));
ii=1;
while ii<=length(pos)-1
    idx= find(pos==pos(ii));
    if length(idx)>1
        val(ii)=sum(val(idx));
        pos(idx(2:length(idx)))=[];
        val(idx(2:length(idx)))=[];
    else
        ii=ii+1;
    end
end
cmp_exp(pos)=val;


idx=find(ismember(exps,cmp_exp,'rows'));

if isempty(idx)~=1
    
    G_at=const_for_G(:,idx);
else
    
    G_at=zeros(size(const_for_G(:,1)));
end
end

function res=kDelta(a,b)

if a==b
    res=1;
else
    res=0;
end
end

function mi_array=multi_index(exp_max,dim,options)
if exp_max>0
a1=0:1:exp_max;
mi_array=a1;
for ii=1:dim-1
    mi_array=combvec(mi_array,a1);
    idx=find(sum(mi_array)>exp_max);
    mi_array(:,idx)=[];
    
end
mi_array(:,1)=[];
if strcmp(options,'same')==1
    idx=find(sum(mi_array)~=exp_max);
    mi_array(:,idx)=[];
end

mi_array=mi_array';
else 
    mi_array=[];
end
end

