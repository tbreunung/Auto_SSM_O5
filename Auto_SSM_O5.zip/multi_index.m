function mi_array=multi_index(exp_max,dim,options)
if exp_max>0
a1=0:1:exp_max;
mi_array=a1;
for ii=1:dim-1
    mi_array=combvec(mi_array,a1);
    idx=find(sum(mi_array)>exp_max);
    mi_array(:,idx)=[];
    
end
mi_array(:,1)=[];
if strcmp(options,'same')==1
    idx=find(sum(mi_array)~=exp_max);
    mi_array(:,idx)=[];
end

mi_array=mi_array';
else 
    mi_array=[];
end
end