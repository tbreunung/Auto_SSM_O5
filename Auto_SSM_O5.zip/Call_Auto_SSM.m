%-------------------------------------------------------------
% This is an exemplary call of Aut_SSM_O5. Please cite [1] if you use this code.
% This script is made public for research only.
% Constructs the Autonomous SSM as given in [1] & [2], for the general nonlinear
% mechanical system
%
% M q_pp +C Q_p + K q +f_nlin(q,q_p)=0.
%
% Assumptions
% -M is invertible
% -f_nlin=O(q^2,q q_p,q_p^2)
% -lightly damped structures
%
% Interested users are also referred to Ponsioen and Haller [3].
%-------------------------------------------------------------

%-------------------------------------------------------------
% Please report malfunctions to:
%       !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%       !!!!!!!!brethoma@ethz.ch!!!!!!!!
%       !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%-------------------------------------------------------------


clear all
close all


% Set up linear system example
M=eye(2);
k1=1;
k2=1;
K=[k1+k2 -k2; -k2 k1+k2];
c1=0.003;
c2=sqrt(3)*10^-3;
C=[c1+c2 -c2; -c2 c1+c2];




%Set up right hand side of first order system
dim=min(size(M));
exps=multi_index(order,2*dim,'smaller');
ex=eye(dim,dim);
vel_idx=zeros(1,dim);
pos_idx=zeros(1,dim);
for ii=1:dim
    
    
    vel_idx(ii)=find(ismember(exps,[zeros(1,dim) ex(ii,:)],'rows'));
    pos_idx(ii)=find(ismember(exps,[ex(ii,:) zeros(1,dim)],'rows'));
end
CM=inv(M)*C;
KM=inv(M)*K;
RHS=zeros(2*dim,length(exps(:,1)));
for ii=1:dim
    RHS(ii,vel_idx(ii))=1;
    RHS(ii+dim,vel_idx)=-CM(ii,:);
    RHS(ii+dim,pos_idx)=-KM(ii,:);
end

%-------------------------------------------------------------
% Specify non linear forcing vector fnlin
%
% fnlin=inv(M)*sum_j^J fnlin(:,j)*x^ms(i)
%           x=[q q_p]^T
%
%Explanations:
% J:        number of nonlinearities of nonlinear forcing vector
% 
% ms:       dimension: J x 2*dim
%           first dim-entries are the exponents of the positions
%           entry dim+1 till 2*dim the exponents of the velocities
%
% fnlin:    dimension: dim*G
%           coefficient vector of nonlinearity
%-------------------------------------------------------------


fnlin=inv(M)*[kappa;0];

ms=[3 0 0 0];
for ii=1:length(ms(:,1))
    idx=find(ismember(exps,ms(ii,:),'rows'));
    for jj=1:dim
        RHS(jj+dim,idx)=-fnlin(jj,ii);
    end
end


%-------------------------------------------------------------
% Input
% M:    N x N       mass matrix
% C:    N x N       damping matirx
% K:    N x N       stiffnes matirx
% Please ensure semisimplicity and Re(lambda)<0
% RHS:  N x multi   Right-hand side of first order equivalent system 
%-------------------------------------------------------------

[W,l,lambda,beta_1,beta_2]=Auto_SSM_O5(M,C,K,RHS,exps);
%-------------------------------------------------------------
%Out:
% W:       sum_(m_1,m_2) W(m_1+1,m_2+1,:).*(z_l^(m_1)+\overbar{z}_l^(m_2))
%          parameterization of the SSM
%          dimensions: order+1 x order+1 x 2*dim
%
% l:       integer (user input)
%          index of the modal subspace to which 2 dimensional SSM is tangent to
%
% lambda:  Eigenvalues
%          dimensions: 2*dim x 1
%
% beta_1:  Coefficient of reduced dynamics (scalar)
%
% beta_2:  Coefficient of reduced dynamics (scalar)
%-------------------------------------------------------------



%-------------------------------------------------------------
%Refferences
%-------------------------------------------------------------
%
% [1] T. Breunung and G. Haller. Explicit backbone curves from spectral
%       submanifolds of forced-damped nonlinear mechanical systems, 2017 
%
% [2] R. Szalai, D. Ehrhardt, and G. Haller. Nonlinear model identication 
%       and spectral submanifolds for multi-degree-of-freedom mechanical 
%       vibrations. Proceedings of the Royal Society of London A: 
%       Mathematical, Physical and Engineering Sciences, 473(2202), 2017
%
%
% Advanced users are also referred to the more advanced code of Ponsionen 
% and Haller: 
%
%              https://github.com/LCSETH/SSMTool
%
% and the publication 
%
% [3] S. Ponsioen, T. Pedergnana and G. Haller. Automated computation 
%       of autonomous spectral submanifolds for nonlinear modal analysis.
%       submitted (2017) https://arxiv.org/abs/1709.00886



